package com.maadcoding.batterysaver

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.maadcoding.batterysaver.ui.theme.BatterySaverTheme
import com.maadcoding.batterysaver.ui.theme.DustyMint
import com.maadcoding.batterysaver.ui.theme.NeonGreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BatterySaverTheme {
                MainScreen()
            }
        }
    }
}

@Composable
fun MainScreen(modifier: Modifier = Modifier) {

    val context = LocalContext.current
    var batteryLowDetected by remember { mutableStateOf(false) }
    var isHeavyAnimationEnabled by remember { mutableStateOf(true) }

    //TODO -> Uncomment this code
    /*Test Case: Opening the application while the battery is already low,
    the UI won't know until the battery level changes again*/

    /*val batteryManager =
        context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    val batteryPercentage =
        batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    batteryLowDetected = batteryPercentage <= 20*/

    if (batteryLowDetected && isHeavyAnimationEnabled)
        BatteryLowSnackBar {
            isHeavyAnimationEnabled = false
        }

    if (isHeavyAnimationEnabled)
        HeavyAnimation()
}

@Composable
fun HeavyAnimation() {

    val transition = rememberInfiniteTransition(label = "")

    val angle = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000)
        ),
        label = ""
    )

    Canvas(
        modifier = Modifier.fillMaxSize()
    ) {
        repeat(500) { i ->

            rotate(angle.value + i) {
                drawCircle(
                    brush = Brush.linearGradient(listOf(NeonGreen, DustyMint)),
                    radius = 50f,
                    center = center.copy(
                        x = center.x + i,
                        y = center.y
                    ),
                )
            }
        }
    }
}

@Composable
fun BatteryLowSnackBar(modifier: Modifier = Modifier, onHideAnimation: () -> Unit) {
    val snackBarHostState = remember { SnackbarHostState() }
    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackBarHostState)
        },
    ) { _ -> }

    LaunchedEffect(Unit) {
        val result = snackBarHostState.showSnackbar(
            message = "Low Battery",
            actionLabel = "Turn on Saver",
            duration = SnackbarDuration.Indefinite
        )
        if (result == SnackbarResult.ActionPerformed)
            onHideAnimation()
    }

}

@Preview(showBackground = true)
@Composable
private fun MainScreenPreview() {
    MainScreen()
}